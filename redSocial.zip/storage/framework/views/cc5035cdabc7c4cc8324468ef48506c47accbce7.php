

<?php $__env->startSection('titulo'); ?>
	<title>Perfil | <?php echo e(session('usuario')->nombre); ?> <?php echo e(session('usuario')->apellido_paterno); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
	<style>
		.btn-action{
			width: 100%;
			background-color: purple;
		}
	</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
	<div class="container-md-10 m-auto">
		<div class="row mt-5 mb-5">
			<div class="col-md-6 col-sm-12">
				<h3 class="text-center">Perfil</h3>
				<div class="col-3">
					<img src="<?php echo e(Storage::url(session('usuario')->foto)); ?>" class="img-thumbnail m-auto" alt="...">
				</div>
				<div class="col-4">
					<?php if(isset($estatus)): ?>
						<?php if($estatus == 'success'): ?>
							<div class="alert alert-success">
								<?php echo e($mensaje); ?>

							</div>
						<?php else: ?>
							<div class="alert alert-warning">
								<?php echo e($mensaje); ?>

							</div>
						<?php endif; ?>
					<?php endif; ?>
					<form action="<?php echo e(route('actualizarPerfil')); ?>" method="POST" enctype="multipart/form-data">
						<?php echo csrf_field(); ?>
						<div class="row">
							<input type="hidden" name="id" value="<?php echo e(session('usuario')->id); ?>">
							<div class="input-group mb-3">
							 	<span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
							  	<input type="text" class="form-control" name="nombre" value="<?php echo e(session('usuario')->nombre); ?>" placeholder="Nombre" aria-label="Username" aria-describedby="basic-addon1">
							</div>
						</div>
						<div class="row">
							<div class="input-group mb-3">
							 	<span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
							  	<input type="text" class="form-control" name="apellidoP" value="<?php echo e(session('usuario')->apellido_paterno); ?>" placeholder="Apellido Paterno" aria-label="Username" aria-describedby="basic-addon1">
							</div>
						</div>
						<div class="row">
							<div class="input-group mb-3">
							 	<span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
							  	<input type="text" class="form-control" name="apellidoM" value="<?php echo e(session('usuario')->apellido_materno); ?>" placeholder="Apellido Materno" aria-label="Username" aria-describedby="basic-addon1">
							</div>
						</div>
						<div class="row">
							<div class="input-group mb-3">
							 	<span class="input-group-text" id="basic-addon1"><i class="fas fa-at"></i></span>
							  	<input type="email" class="form-control" name="email" value="<?php echo e(session('usuario')->correo); ?>" placeholder="Correo" aria-label="Username" aria-describedby="basic-addon1">
							</div>
						</div>
						<div class="row">
							<div class="input-group mb-3">
							 	<span class="input-group-text" id="basic-addon1"><i class="fas fa-image"></i></span>
							  	<input type="file" class="form-control" name="fotoperfil" aria-label="Username" aria-describedby="basic-addon1">
							</div>
							<?php $__errorArgs = ['fotoperfil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<small class="text-danger">Debe de ser una foto</small>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
						<button type="submit" class="btn btn-success w-100">Actualizar</button>
					</form>
					<a href="<?php echo e(route('descargarInfo')); ?>" target="_blank" class="btn btn-info">Descargar informacion</a>
				</div>
				<div class="card">
					<div class="row">
						<div class="col-12 d-flex justify-content-between">
							<div class="col-2"><h4>Fotos</h4></div>
							<div class="col-2">
								<button class="btn btn-secondary" type="button" data-bs-toggle="collapse" data-bs-target="#fotos" aria-expanded="false" aria-controls="fotos">
									<i class="fas fa-plus"></i>
								</button>
							</div>
						</div>
						<div class="col-12 collapse" id="fotos">
							<div class="d-flex col-12">
								<div class="row">
									<?php if($fotos->count() > 0): ?>
										<?php $__currentLoopData = $fotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $foto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($foto->imagen != null): ?>
												<div class="col-md-3">
													<img src="<?php echo e(Storage::url($foto->imagen)); ?>" class="rounded w-75 ml-2" alt="...">
												</div>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php else: ?>
										<div class="alert alert-warning">
											Aun no hay fotos para mostrar
										</div>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-6 col-sm-12">
				<h2 class="text-center">Publicaciones</h2>
				<div class="col-md-12 col-sm-12">
					<?php if($publicaciones->count() > 0): ?>
						<?php $__currentLoopData = $publicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $publicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="card mt-5 mb-2 w-75 m-auto">
								<span class="border border-top border-warning border-2"></span>
								<div class="row">
									<div class="row">
										<div class="col-md-6 ml-2">
											<img src="<?php echo e(Storage::url($publicacion->foto)); ?>" class="rounded-circle w-25 ml-2" alt="...">
											<a href="<?php echo e(route('verPerfil', ['idusuario' => $publicacion->user_id])); ?>"><?php echo e($publicacion->nombre); ?></a>
										</div>
										<div class="col-md-6">
											<p class="text-primary text-right">
												<?php echo e($publicacion->created_at); ?>

											</p>
										</div>
									</div>
									<div class="row">
										<?php if($publicacion->texto != null): ?>
											<div class="row">
												<p><?php echo e($publicacion->texto); ?></p>
											</div>
										<?php endif; ?>
										<?php if($publicacion->imagen != null): ?>
											<div class="row mb-2">
												<img src="<?php echo e(Storage::url($publicacion->imagen)); ?>" alt="Imagen si hay">
											</div>
										<?php endif; ?>
									</div>
								</div>
								<div class="row">
									<div class="col-6">
										<button type="button" onclick="like(<?php echo e($publicacion->id); ?>)" class="btn btn-action w-100 text-center"><i class="fas fa-heart"></i> <?php echo e($publicacion->likes); ?></button>
									</div>
									<div class="col-6">
										<button class="btn btn-action" type="button" data-bs-toggle="collapse" data-bs-target="#comentarios" aria-expanded="false" aria-controls="comentarios">
				    						<i class="fas fa-comment"></i>
				  						</button>
									</div>
								</div>
								<div class="collapse" id="comentarios">
								  	<div class="card">
								  		<div class="card-header">
								  			<div class="col-md-12 ml-2">
												<div class="col-4">
													<img src="<?php echo e(Storage::url('default.png')); ?>" class="rounded-circle w-25 ml-2" alt="...">
												</div>
												<a href="">Usuario</a>
											</div>
											<div class="col-12">
												<form action="" method="POST" id="formComentario">
													<?php echo csrf_field(); ?>
													<input type="hidden" name="idusuario" value="<?php echo e(session('usuario')->id); ?>">
													<div class="input-group">
													  	<span class="input-group-text">Escribe</span>
													  	<textarea class="form-control" name="comentario" aria-label="With textarea" placeholder="Que piensas?"></textarea>
													</div>
													<button type="button" onclick="comentar(<?php echo e($publicacion->id); ?>)" class="btn btn-primary">Comentar</button>
												</form>
											</div>
								  		</div>
								  		<div class="card-body">
								  			<div class="row">
								  				<?php $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comentario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								  					<?php if($comentario->publicacionId == $publicacion->id): ?>
								  						<div class="col-12">
															<p>
																<?php echo e($comentario->texto); ?>

															</p>
														</div>
								  					<?php endif; ?>
								  				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								  			</div>
								  		</div>
								  	</div>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
						<div class="alert alert-warning">
							Aun no hay publicaciones
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script>
		function like(id) {
			$.ajax({
				headers: {
			        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			    },
				url: "<?php echo e(route('like')); ?>/"+id,
				type: 'POST',
				dataType: 'json',
				success: function (data){
					if (data.estatus == 'success'){
						alert(data.mensaje);
						location.reload();
					}else{
						alert(data.mensaje);
					}
				},
			});
		}

		function comentar(idpublicacion) {
			$.ajax({
				url: "<?php echo e(route('comentar')); ?>/"+idpublicacion,
				type: 'POST',
				dataType: 'json',
				data: $('#formComentario').serialize(),
				success: function(data){
					if (data.estatus == 'success'){
						alert(data.mensaje);
						location.reload();
					}else{
						alert(data.mensaje);
					}
				},
			});
		}
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\redSocial\resources\views/perfil.blade.php ENDPATH**/ ?>