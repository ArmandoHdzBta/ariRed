

<?php $__env->startSection('titulo'); ?>
	<title>Registrarse</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
	<div class="card w-50 m-auto mt-5">
		<h3 class="card-title text-center">Registrate</h3>
		<?php if(isset($estatus)): ?>
			<?php if($estatus == 'error'): ?>
				<div class="alert alert-warning">
					<?php echo e($mensaje); ?>

				</div>
			<?php else: ?>
				<div class="alert alert-danger">
					<?php echo e($mensaje); ?>

				</div>
			<?php endif; ?>
		<?php endif; ?>
		<form action="<?php echo e(route('registro')); ?>" method="POST">
			<?php echo csrf_field(); ?>
			<div class="row">
				<div class="input-group mb-3">
				 	<span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
				  	<input type="text" class="form-control" name="nombre" placeholder="Nombre" aria-label="Username" aria-describedby="basic-addon1">
				</div>
			</div>
			<div class="row">
				<div class="input-group mb-3">
				 	<span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
				  	<input type="text" class="form-control" name="apellidoP" placeholder="Apellido Paterno" aria-label="Username" aria-describedby="basic-addon1">
				</div>
			</div>
			<div class="row">
				<div class="input-group mb-3">
				 	<span class="input-group-text" id="basic-addon1"><i class="fas fa-user"></i></span>
				  	<input type="text" class="form-control" name="apellidoM" placeholder="Apellido Materno" aria-label="Username" aria-describedby="basic-addon1">
				</div>
			</div>
			<div class="row">
				<div class="input-group mb-3">
				 	<span class="input-group-text" id="basic-addon1"><i class="fas fa-at"></i></span>
				  	<input type="email" class="form-control" name="email" placeholder="Correo" aria-label="Username" aria-describedby="basic-addon1">
				</div>
			</div>
			<div class="row">
				<div class="input-group mb-3">
				 	<span class="input-group-text" id="basic-addon1"><i class="fas fa-key"></i></span>
				  	<input type="password" class="form-control" name="password1" placeholder="Contraseña" aria-label="Username" aria-describedby="basic-addon1">
				</div>
			</div>
			<div class="row">
				<div class="input-group mb-3">
				 	<span class="input-group-text" id="basic-addon1"><i class="fas fa-key"></i></span>
				  	<input type="password" class="form-control" name="password2" placeholder="Repite la contraseña" aria-label="Username" aria-describedby="basic-addon1">
				</div>
			</div>
			<button type="submit" class="btn btn-success w-100">Registrarse</button>
		</form>
		<a href="<?php echo e(route('login')); ?>" class="btn-link">Iniciar sesion</a>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout-forms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\redSocial\resources\views/registrarse.blade.php ENDPATH**/ ?>