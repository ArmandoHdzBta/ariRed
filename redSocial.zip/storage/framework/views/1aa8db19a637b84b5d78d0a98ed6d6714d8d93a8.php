

<?php $__env->startSection('titulo'); ?>
	<title>Usuarios</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
	<div class="container">
		<div class="row mt-5 mb-5">
			<div class="col-6 m-auto">
				<ul class="list-group list-group-flush">
					<?php if($usuarios->count() > 0): ?>
						<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<li class="list-group-item">
								<div class="row d-flex justify-content-between">
									<div class="col">
										<a href="<?php echo e(route('verPerfil', ['idusuario' => $usuario->id])); ?>"><?php echo e($usuario->nombre); ?> <?php echo e($usuario->apellido_paterno); ?></a>
									</div>
									<div class="col">
										<button type="button" id="btnAmigo" onclick="addAmigo(<?php echo e($usuario->id); ?>)" class="btn btn-outline-warning">
											Añadir amigo
										</button>
									</div>
								</div>
							</li>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php else: ?>
						<div class="alert alert-warning">
							aun no hay demaciados usuarios
						</div>
					<?php endif; ?>
				</ul>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
	<script>
		function addAmigo(id) {
			$.ajax({
				headers: {
			        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			    },
				url: "<?php echo e(route('addAmigo')); ?>/"+id,
				type: 'POST',
				dataType: 'json',
				success: function (data){
					if(data.estatus == 'success'){
						alert(data.mensaje);
					}else{
						alert(data.mensaje);
					}
				},
			});

		}
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\redSocial\resources\views/usuarios.blade.php ENDPATH**/ ?>