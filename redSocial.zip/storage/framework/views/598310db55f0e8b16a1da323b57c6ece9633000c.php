

<?php $__env->startSection('titulo'); ?>
	<title>Iniciar sesion</title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
	<div class="card w-50 m-auto mt-5">
		<h3 class="card-title text-center">Inicia sesion</h3>
		<?php if(isset($estatus)): ?>
			<?php if($estatus == 'success'): ?>
				<div class="alert alert-success">
					<?php echo e($mensaje); ?>

				</div>
			<?php else: ?>
				<div class="alert alert-warning">
					<?php echo e($mensaje); ?>

				</div>
			<?php endif; ?>
		<?php endif; ?>
		<form action="<?php echo e(route('verificar')); ?>" method="POST">
			<?php echo csrf_field(); ?>
			<div class="row">
				<div class="input-group mb-3">
				 	<span class="input-group-text" id="basic-addon1"><i class="fas fa-at"></i></span>
				  	<input type="email" class="form-control" name="email" placeholder="Correo" aria-label="Username" aria-describedby="basic-addon1">
				</div>
			</div>
			<div class="row">
				<div class="input-group mb-3">
				 	<span class="input-group-text" id="basic-addon1"><i class="fas fa-key"></i></span>
				  	<input type="password" class="form-control" name="password" placeholder="Contraseña" aria-label="Username" aria-describedby="basic-addon1">
				</div>
			</div>
			 <?php if(isset($_GET["oops"])): ?>
		      	<input type="hidden" name="url" value="<?php echo e($_GET["oops"]); ?>">
		    <?php endif; ?>
			<button type="submit" class="btn btn-success">Iniciar sesion</button>
		</form>
		<a href="<?php echo e(route('registrarse')); ?>" class="btn-link">Registrarse</a>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.layout-forms', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\redSocial\resources\views/login.blade.php ENDPATH**/ ?>